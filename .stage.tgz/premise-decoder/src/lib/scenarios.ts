import { emptyInput, type EvalInput } from "./engine";

export interface Scenario {
  id: string;
  title: string;
  note: string;
  expected: string;
  input: EvalInput;
}

export const SCENARIOS: Scenario[] = [
  {
    id: "botox-special",
    title: "\u201cBotox special \u2014 today only\u201d \u00b7 day spa",
    note: "High-burden injectable in a day-spa setting with weak oversight and identity gaps.",
    expected: "Expect: unnamed on product, performer, after-hours.",
    input: {
      ...emptyInput,
      serviceClass: "injectable",
      venue: "day-spa",
      region: "us-az",
      menuLine: "Botox special",
      product: "",
      performer: "Injection specialist",
      price: "$9 per unit",
      afterHours: "Front desk voicemail during business hours",
      seriesPressure: "Rebook every 3 months, prepay 4 sessions",
      marketing:
        "Botox special \u2014 today only! $9 per unit with our injection specialist. Painless, no downtime, walk out looking refreshed. Voted best in the valley.",
    },
  },
  {
    id: "tox-named-good",
    title: "Named neuromodulator, NP injector, medical director listed \u00b7 med-spa",
    note: "Strong disclosure baseline for injectables: product, performer, oversight, after-hours all resolved.",
    expected: "Expect: mostly known; residual questions minimal.",
    input: {
      ...emptyInput,
      serviceClass: "injectable",
      venue: "med-spa",
      region: "us-co",
      menuLine: "Botox Cosmetic, glabella + forehead, 40 units",
      product: "Botox Cosmetic (onabotulinumtoxinA), 40 units",
      performer: "Nurse practitioner injector",
      license: "NP, verifiable with the state board",
      price: "$13 per unit",
      supervision: "Medical director named, reachable during and after hours",
      sanitation: "Single-use vial and needles; reconstitution shown",
      afterHours: "24/7 cell line to the NP; escalation to the MD documented",
      consent: "Written consent and pre/post photos",
      seriesPressure: "Re-treat at 3\u20134 months, no prepay",
      marketing:
        "Botox Cosmetic placed by our nurse practitioner under a named medical director. We show you the vial, the units, and the plan.",
    },
  },
  {
    id: "lip-flip-flash",
    title: "'Lip flip' flash sale \u00b7 unnamed injector",
    note: "Cheap injectable, undisclosed product and performer scope, social-only aftercare.",
    expected: "Expect: unnamed on product and performer; after-hours flagged.",
    input: {
      ...emptyInput,
      serviceClass: "injectable",
      venue: "med-spa",
      region: "us-nv",
      menuLine: "Lip flip flash sale",
      product: "",
      performer: "Aesthetic provider",
      price: "$99 flat",
      afterHours: "DM us on Instagram",
      seriesPressure: "Book 3, get 1 free",
      marketing:
        "Lip flip flash sale \u2014 $99 today only. Subtle, natural, no downtime. Our aesthetic provider takes care of you. Link in bio.",
    },
  },
  {
    id: "ipl-no-screen",
    title: "IPL photofacial, no device or skin-type screening named",
    note: "Light-based device with 'safe for everyone' language, no device named, no settings or skin-type screening disclosed.",
    expected:
      "Expect: device unnamed; 'safe for everyone' flagged as an unresolved screening claim.",
    input: {
      ...emptyInput,
      serviceClass: "device",
      venue: "day-spa",
      region: "unstated",
      menuLine: "IPL photofacial for glow",
      product: "",
      performer: "Laser technician",
      price: "$120",
      supervision: "Medical director available by phone",
      afterHours: "Studio voicemail",
      marketing:
        "IPL photofacial for instant glow and even tone. Safe for everyone. Walk in on your lunch break.",
    },
  },
  {
    id: "vi-peel-named",
    title: "Named VI Peel with aftercare \u00b7 med-spa",
    note: "Branded peel with named ingredients, licensed operator, supervision, and consent \u2014 a usable path.",
    expected: "Expect: mostly known; tier language absent, which is the point.",
    input: {
      ...emptyInput,
      serviceClass: "chemical",
      venue: "med-spa",
      region: "us-tx",
      menuLine: "VI Peel, full face",
      product: "VI Peel (branded blend; ingredients listed on consent)",
      performer: "Licensed aesthetician",
      license: "State aesthetician license displayed",
      price: "$300",
      supervision: "Supervising dermatologist named",
      sanitation: "Single-use applicators",
      consent: "Written consent, printed aftercare, day-3 check-in call",
      seriesPressure: "Optional series of 3, spaced 4 weeks, no prepay",
      marketing:
        "A VI Peel by a licensed aesthetician under a supervising dermatologist. You get the ingredient list and written aftercare before we start.",
    },
  },
  {
    id: "exosome-microneedling",
    title: "Microneedling with 'exosome' add-on, source undisclosed",
    note: "Barrier-crossing device plus an add-on whose source, contents, and regulatory status are undisclosed.",
    expected:
      "Expect: product unnamed on 'proprietary'; add-on mechanism flagged; supervision unknown.",
    input: {
      ...emptyInput,
      serviceClass: "device",
      venue: "med-spa",
      region: "us-ca",
      menuLine: "Microneedling + exosome glow booster",
      product: "Proprietary exosome serum",
      performer: "Skin specialist",
      price: "$450 with booster",
      afterHours: "Text the front desk",
      marketing:
        "Supercharge your microneedling with our exosome glow booster for next-level regeneration. Ask about our signature protocol.",
    },
  },
  {
    id: "body-contour-guarantee",
    title: "Fat-freezing 'guaranteed inches' package",
    note: "Outcome guarantee and unnamed device with a large prepay commitment.",
    expected: "Expect: guarantee flagged; device unnamed; commitment structure flagged.",
    input: {
      ...emptyInput,
      serviceClass: "device",
      venue: "med-spa",
      region: "us-fl",
      menuLine: "Body contouring \u2014 lose inches guaranteed",
      product: "Fat-freezing device",
      performer: "Body contouring specialist",
      price: "$2,400 package of 4 areas",
      seriesPressure: "4 areas, prepay for best price",
      afterHours: "Email",
      marketing:
        "Freeze away stubborn fat \u2014 guaranteed inches lost or your money back. FDA-cleared technology. Our specialist customizes every session.",
    },
  },
  {
    id: "morpheus-signature",
    title: "'Signature' RF microneedling, settings undisclosed",
    note: "Good operator and oversight disclosure, but the device is hidden behind 'signature' branding and settings are unstated.",
    expected: "Expect: performer and oversight known; device unnamed on 'signature'.",
    input: {
      ...emptyInput,
      serviceClass: "device",
      venue: "med-spa",
      region: "us-ny",
      menuLine: "Signature RF microneedling facial",
      product: "RF microneedling platform (brand withheld as 'signature')",
      performer: "Registered nurse",
      license: "RN",
      price: "$900 per session",
      supervision: "Physician medical director named",
      sanitation: "Single-use tips shown",
      afterHours: "RN cell line for 48 hours",
      consent: "Written consent",
      marketing:
        "Our signature RF microneedling tightens and refines, performed by our RN with a physician medical director.",
    },
  },
  {
    id: "kybella-scope",
    title: "Kybella double-chin, injector scope unclear",
    note: "Named product but injector credential/scope and consent undisclosed; multi-session cost not totaled.",
    expected: "Expect: product known; performer scope and consent flagged; series cost surfaced.",
    input: {
      ...emptyInput,
      serviceClass: "injectable",
      venue: "med-spa",
      region: "us-il",
      menuLine: "Double-chin dissolving injections",
      product: "Kybella (deoxycholic acid)",
      performer: "Aesthetic injector",
      price: "$600 per vial, usually 2\u20134 vials",
      seriesPressure: "Most need 2\u20134 sessions",
      afterHours: "Front desk hours only",
      marketing:
        "Dissolve your double chin for good with Kybella. Most clients love it in 2\u20134 sessions. Book your consult.",
    },
  },
  {
    id: "thread-facelift",
    title: "PDO thread 'non-surgical facelift' permanence",
    note: "'Facelift' and permanence language for a temporary device; thread type and complication plan undisclosed.",
    expected:
      "Expect: 'facelift'/permanence flagged; product partial; complication protocol unknown.",
    input: {
      ...emptyInput,
      serviceClass: "injectable",
      venue: "med-spa",
      region: "us-ga",
      menuLine: "Non-surgical facelift with threads",
      product: "PDO threads (type unspecified)",
      performer: "Master injector",
      price: "$1,800",
      afterHours: "On-call line, hours unstated",
      marketing:
        "Our non-surgical facelift lifts and snatches with dissolvable threads \u2014 instant results that last, by our master injector.",
    },
  },
  {
    id: "hydrafacial-booster",
    title: "HydraFacial with undisclosed 'booster' actives",
    note: "Branded low-risk device with an add-on whose active, source, and evidence are undisclosed; consent verbal.",
    expected: "Expect: base service known; booster active unnamed; consent flagged as verbal-only.",
    input: {
      ...emptyInput,
      serviceClass: "device",
      venue: "day-spa",
      region: "us-wa",
      menuLine: "HydraFacial Deluxe with boosters",
      product: "HydraFacial (branded) + growth-factor booster",
      performer: "Esthetician",
      license: "State esthetician license",
      price: "$249",
      consent: "Verbal only",
      marketing:
        "Our Deluxe HydraFacial adds a growth-factor booster for glow that lasts. Add LED for extra results.",
    },
  },
];
